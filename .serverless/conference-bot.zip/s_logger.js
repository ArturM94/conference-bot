var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'klischvolodimir',
applicationName: 'telegram-conference-bot',
appUid: 'ThxH9fdPrYnrzCMMyq',
orgUid: 'przyCWhPjHJ4d5rb3p',
deploymentUid: '90756651-b3c0-4c27-a54f-2e4157beaf9f',
serviceName: 'conference-bot',
stageName: 'dev',
pluginVersion: '3.4.0'})
const handlerWrapperArgs = { functionName: 'conference-bot-dev-logger', timeout: 6}
try {
  const userHandler = require('./src/aws/handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.logger, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
