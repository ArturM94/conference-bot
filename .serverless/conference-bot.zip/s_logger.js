var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'klischvolodimir',
applicationName: 'telegram-conference-bot',
appUid: 'ThxH9fdPrYnrzCMMyq',
orgUid: 'przyCWhPjHJ4d5rb3p',
deploymentUid: '154d009f-e43c-4c77-b335-33e0bc5ee720',
serviceName: 'conference-bot',
stageName: 'prod',
pluginVersion: '3.4.0'})
const handlerWrapperArgs = { functionName: 'conference-bot-prod-logger', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.logger, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
